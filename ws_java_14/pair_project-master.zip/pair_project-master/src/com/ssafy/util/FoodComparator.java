package com.ssafy.util;

import java.util.Comparator;

import com.ssafy.vo.Food;

public class FoodComparator implements  Comparator<Food>{
	private String orderBy;
	public FoodComparator(String orderBy) {
		this.orderBy=orderBy;
	}
	@Override
	public int compare(Food o1, Food o2) {
		if(orderBy.equals("번호")) {
			return o1.getCode()-o2.getCode();
		}else if(orderBy.equalsIgnoreCase("식품명")) {
			return o1.getName().compareTo(o2.getName());
		}else {
			return o1.getMaterial().compareTo(o2.getMaterial());
		}
	}

}
