package com.ssafy.util;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

import com.ssafy.vo.Food;

/**
 *  FoodNutritionInfo.xml 파일에서 식품 영양 정보를 읽어 파싱하는 핸들러 클래스 
 */
public class FoodSAXHandler extends DefaultHandler {
	/**파싱한 식품 영양 정보를 담는 리스트 */
	private List<Food> list;
	/**파상힌 식품 영양 정보*/
	private Food food;
	/**태그 바디 정보를 임시로 저장*/
	private String temp;
	public FoodSAXHandler(){
		list = new LinkedList<Food>();
	}
	public void startElement(String uri, String localName
			                           , String qName, Attributes att ){
		if(qName.equals("item")){
			food = new Food();
		}
	}
	public void endElement(String uri, String localName, String qName){
		if(qName.equals("prdlstNm")) { 
			food.setName(temp);
		}else if(qName.equals("prdlstReportNo")) { 
			food.setSupportpereat(changeData(temp));
		}else if(qName.equals("rnum")) { 
			food.setCode(Integer.parseInt(temp));
		}else if(qName.equals("rnum")) { 
			food.setCode(Integer.parseInt(temp));
		}else if(qName.equals("imgurl1")) { 
			food.setImg(temp);
		}else if(qName.equals("allergy")) { 
			food.setAllergy(temp);
		}else if(qName.equals("rawmtrl")) { 
			food.setMaterial(temp);
		}else if(qName.equals("nutrient")) { 
			StringTokenizer st=new StringTokenizer(temp);
			while(st.hasMoreTokens()) {
				String aa=st.nextToken();
				if(aa.contains("kcal")) {
					food.setCalory(aa);
				}else if(aa.contains("탄수화물")) {
					food.setCarbo(aa);
				}else if(aa.contains("단백질")) {
					food.setProtein(aa);
				}else if(aa.contains("포화지방")) {
					food.setFattyacid(aa);
				}else if(aa.contains("당류")) {
					food.setSugar(aa);
				}else if(aa.contains("나트륨")) {
					food.setNatrium(aa);
				}else if(aa.contains("트랜스지방")) {
					food.setTransfat(aa);
				}else if(aa.contains("지방")) {
					food.setFat(aa);
				}
			}
		}else if(qName.equals("manufacture")) { 
			StringTokenizer st=new StringTokenizer(temp);
			
			food.setMaker(st.nextToken());
		}
			else if(qName.equals("item")) { 
			list.add(food);
		}
	}
	public double changeData(String data) {
		if(data.equals("")||data.equalsIgnoreCase("N/A")) {
			return 0;
		}else{
			return Double.parseDouble(data);
		}
	}
	public void characters(char[]ch, int start, int length){
		temp =new String(ch, start, length).trim();
	}
	public List<Food> getList() {	return list;	}
	public void setList(List<Food> list) {	this.list = list;	}
}





